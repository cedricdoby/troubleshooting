'use strict';

angular.module('<%= scriptAppName %>.util', []);
