# Media

> Angular Full Stack Generator logo and artwork

[![](svg/angular-fullstack-logo.svg)](optimized)


## License

[![Creative Commons License](http://i.creativecommons.org/l/by/4.0/80x15.png)](http://creativecommons.org/licenses/by/4.0/)
