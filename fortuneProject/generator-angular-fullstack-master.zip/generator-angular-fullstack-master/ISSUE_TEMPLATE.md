 - [ ] I understand that GitHub issues are not for tech support, but for questions specific to this generator, bug reports, and feature requests.

Item | Version
----- | -----
generator-angular-fullstack | x.x.x
Node | x.x.x
npm | x.x.x
Operating System | OS X 10 / Windows 10 / Ubuntu 15.10 / etc
etc | etc

Item | Answer
----- | -----
Transpiler | Babel / TypeScript
Markup | HTML / Jade
CSS | CSS / LESS / SCSS / Stylus
Router | ngRoute / ui-router
Build Tool | Grunt / Gulp
Client Tests | Jasmine / Mocha
DB | MongoDB / SQL
Auth | Y / N
etc | etc
